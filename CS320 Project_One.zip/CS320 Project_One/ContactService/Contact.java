/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

/*///////////////////////////////////////////////////////////////////////////
/ Class Purpose: 															/
/ To use in-memory data structures for a contact list service including :	/
/  Unique ContactID no longer than 10 characters, never null, not updatable	/
/  String FirstName no longer than 10 characters, never null				/
/  String LastName no longer than 10 characters, never null					/
/  String Number exactly 10 characters, never null							/
/  String Address no longer than 30 characters, never null					/
///////////////////////////////////////////////////////////////////////////*/
public class Contact {
	private String contactID;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	//Constructor
	public Contact(String contactID, String firstName, String lastName, String number, String address) {
		if(contactID == null || contactID.length() > 10) {
			//test for exception
			throw new IllegalArgumentException("Invalid Input");
		}
		
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		
		if(number == null || number.length() != 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
			
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Input");
		}
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.address = address;
	}
	
	//set accessor methods
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.lastName = lastName;
	}
	
	public void setNumber(String number) {
		if(number == null || number.length() != 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.number = number;
	}
	
	public void setAddress(String address) {
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.address = address;
	}
	
	//get accessor methods
	public String getContactID() {
		return this.contactID;
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public String getNumber() {
		return this.number;
	}
	
	public String getAddress() {
		return this.address;
	}
}
