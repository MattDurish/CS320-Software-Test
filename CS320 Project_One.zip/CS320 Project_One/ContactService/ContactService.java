/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import java.util.ArrayList;

/*///////////////////////////////////////////
/ Class Purpose: 							/
/ To add contacts with a unique contactID	/
/ To delete contacts per contactID			/
/ To update contact fields per contactID :	/
/   firstName, lastName, number, address	/
///////////////////////////////////////////*/

public class ContactService {
	//initialize a list of unique contacts for data usage
	public ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	//find contact method
	public int findContactID(String contactID) {
		for(int i = 0; i < contacts.size(); i++) {
			if(contacts.get(i).getContactID() == contactID) {
				//return index if found
				return i;
			}
		}
		//return -1 if not found
		return -1;
	}
	
	//add contact method
	public void addContact(String contactID, String firstName, String lastName, String number, String address) {
		int location = findContactID(contactID);
		
		//add contact if not found
		if(location == -1) {
			Contact newContact = new Contact(contactID, firstName, lastName, number, address);
			contacts.add(newContact);
		} else {
			//contact was found and not added or updated to current list
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	//delete contact method
	public void deleteContact(String contactID) {
		int location = findContactID(contactID);
		
		//if found, can remove from list
		if(location != -1) {
			contacts.remove(location);
		} else {
			//contactID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	//update contact methods
	public void updateFirstName(String contactID, String firstName) {
		int location = findContactID(contactID);
		
		//if found, can update firstName
		if(location != -1) {
			contacts.get(location).setFirstName(firstName);
		} else {
			//contactID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	public void updateLastName(String contactID, String lastName) {
		int location = findContactID(contactID);
		
		//if found, can update firstName
		if(location != -1) {
			contacts.get(location).setLastName(lastName);
		} else {
			//contactID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	public void updateNumber(String contactID, String number) {
		int location = findContactID(contactID);
		
		//if found, can update firstName
		if(location != -1) {
			contacts.get(location).setNumber(number);
		} else {
			//contactID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	public void updateAddress(String contactID, String address) {
		int location = findContactID(contactID);
		
		//if found, can update firstName
		if(location != -1) {
			contacts.get(location).setAddress(address);
		} else {
			//contactID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
}
