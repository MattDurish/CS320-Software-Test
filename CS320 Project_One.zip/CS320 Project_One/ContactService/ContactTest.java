/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	//success case
	@Test
	void testContact() {
		Contact contact = new Contact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		assertTrue(contact.getContactID().equals("001"));
		assertTrue(contact.getFirstName().equals("Rick"));
		assertTrue(contact.getLastName().equals("Deckard"));
		assertTrue(contact.getNumber().equals("5555551234"));
		assertTrue(contact.getAddress().equals("1234 Lombard St"));
		
		contact.setFirstName("Racheal");
		contact.setLastName("Rosen");
		contact.setNumber("5559995678");
		contact.setAddress("5678 Rosen Association");
		
		assertTrue(contact.getFirstName().equals("Racheal"));
		assertTrue(contact.getLastName().equals("Rosen"));
		assertTrue(contact.getNumber().equals("5559995678"));
		assertTrue(contact.getAddress().equals("5678 Rosen Association"));
	}

	//contactID test for length and null
	@Test
	void testContactIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("00145678911", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		});
	}

	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Rick", "Deckard", "5555551234", "1234 Lombard St");
		});
	}
	
	//firstName test for length and null
	@Test
	void testContactFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "R2i4c6k8911", "Deckard", "5555551234", "1234 Lombard St");
		});
	}

	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", null, "Deckard", "5555551234", "1234 Lombard St");
		});
	}
	
	//lastName test for length and null
	@Test
	void testContactLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", "D2e4c6k8a11r14d17", "5555551234", "1234 Lombard St");
		});
	}

	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", null, "5555551234", "1234 Lombard St");
		});
	}
	
	//number test for length and null
	@Test
	void testContactNumberToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", "Deckard", "55555512345", "1234 Lombard St");
		});
	}
	
	@Test
	void testContactNumberToShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", "Deckard", "555555123", "1234 Lombard St");
		});
	}

	@Test
	void testContactNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", "Deckard", null, "1234 Lombard St");
		});
	}
	
	//address test for length and null
	@Test
	void testContactAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", "Deckard", "555555123", "1234 6L8o11m14b17a20r23d26 29St33");
		});
	}

	@Test
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("001", "Rick", "Deckard", "5555551234", null);
		});
	}
}
