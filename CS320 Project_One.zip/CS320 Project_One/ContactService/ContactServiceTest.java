/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	//success case
	@Test
	void testContactService() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		contacts.addContact("002", "Racheal", "Rosen", "5559995678", "5678 Rosen Association");		
		contacts.updateFirstName("001", "Isidore");
		contacts.updateLastName("002", "Petra");
		contacts.updateNumber("001", "1234567890");
		contacts.updateAddress("002", "Mr. Ishidore Apartment");
		contacts.deleteContact("001");
	}

	@Test
	void testContactServiceAddDuplicate() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contacts.addContact("001", "Racheal", "Rosen", "5559995678", "5678 Rosen Association");
		});
	}
	
	@Test
	void testContactServiceDeletePerIDNotFound() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contacts.deleteContact("002");
		});
	}
	
	@Test
	void testContactServiceUpdateFirstNamePerIDNotFound() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contacts.updateFirstName("002", "Racheal");
		});
	}
	
	@Test
	void testContactServiceUpdateLastNamePerIDNotFound() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contacts.updateLastName("002", "Rosen");
		});
	}
	
	@Test
	void testContactServiceUpdateNumberPerIDNotFound() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contacts.updateNumber("002", "5559995678");
		});
	}
	
	@Test
	void testContactServiceUpdateAddressPerIDNotFound() {
		ContactService contacts = new ContactService();
		contacts.addContact("001", "Rick", "Deckard", "5555551234", "1234 Lombard St");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contacts.updateAddress("002", "5678 Rosen Association");
		});
	}
}
