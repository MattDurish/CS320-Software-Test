/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	//success case
	@Test
	void testAppt() {
		//constructor test
		Appointment appt = new Appointment("001", "2025-06-15", "Doctor Meng");
		assertTrue(appt.getApptID().equals("001"));
		assertTrue(appt.getApptDate().equals("2025-06-15"));
		assertTrue(appt.getDesc().equals("Doctor Meng"));
		
		//set all possible attributes
		appt.setApptDate("2025-12-30");
		appt.setDesc("Dentist");
		
		//test new attributes
		assertTrue(appt.getApptDate().equals("2025-12-30"));
		assertTrue(appt.getDesc().equals("Dentist"));
	}

	//apptID test for length, empty string, and null
	@Test
	void testApptIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("12345678911", "2025-06-15", "Doctor Meng");
		});
	}
	@Test
	void testApptIDEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("", "2025-06-15", "Doctor Meng");
		});
	}
	@Test
	void testApptIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, "2025-06-15", "Doctor Meng");
		});
	}
	
	
	//apptDate test for before date, empty string, and null
	@Test
	void testApptDateBefore() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("001", "2020-01-01", "Doctor Meng");
		});
	}
	@Test
	void testApptDateEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", "", "Doctor Meng");
		});
	}
	@Test
	void testApptDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", null, "Doctor Meng");
		});
	}
	@Test
	void testApptDateBadData() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", "January 15th Twenty Tweny Five", "Doctor Meng");
		});
	}
	
	//desc test for length, empty string, and null
	@Test
	void testDescToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("001", "2025-06-15", "D2o4c6t8o11r14 17M20e23n26g293133353739414345474951");
		});
	}
	@Test
	void testDescEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", "2025-06-15", "");
		});
	}
	@Test
	void testDescNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", "2025-06-15", null);
		});
	}
}
