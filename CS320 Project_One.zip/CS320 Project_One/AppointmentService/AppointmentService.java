/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import java.util.ArrayList;

/*///////////////////////////////////////////
/ Class Purpose: 							/
/ To add appointments per apptID			/
/ To delete appointments per apptID			/
///////////////////////////////////////////*/

public class AppointmentService {
	//initialize a list of unique appointments for data usage
	public ArrayList<Appointment> appts = new ArrayList<Appointment>();
	
	//find appt method
	public int findApptID(String apptID) {
		for(int i = 0; i < appts.size(); i++) {
			if(appts.get(i).getApptID() == apptID) {
				//return index if found
				return i;
			}
		}
		//return -1 if not found
		return -1;
	}
		
	//add appt method
	public void addAppt(String apptID, String apptDate, String desc) {
		int location = findApptID(apptID);
				
		//add appt if not found
		if(location == -1) {
			Appointment newAppt = new Appointment(apptID, apptDate, desc);
			appts.add(newAppt);
		} else {
			//taskID was found, already exists, do not add to list
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	//delete appt method
	public void deleteAppt(String apptID) {
		int location = findApptID(apptID);
					
		//delete appt if found
		if(location != -1) {
			appts.remove(location);
		} else {
			//apptID was not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
}
