/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;

/*///////////////////////////////////////////////////////////////////////////
/ Class Purpose: 															/
/ To use in-memory data structures for storing appointments including :		/
/  Unique apptID: no longer than 10 characters, never null, not updatable	/
/  String apptDate: never a past date, never null 							/
/  String description: no longer than 50 characters, never null				/
///////////////////////////////////////////////////////////////////////////*/

public class Appointment {
	//class attributes
	private String apptID;
	private String apptDate;
	private String desc;
	
	//Constructor
	public Appointment(String apptID, String apptStrDate, String desc) {
		//prep for converting the input date to date format
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		if(apptID == null || apptID.isEmpty() || apptID.length() > 10) {
			//test for exception
			throw new IllegalArgumentException("Invalid ID Input");
		}
		
		//catch instance of null before parsing to prevent unexpected errors
		if(apptStrDate == null || apptStrDate.isEmpty()) {
			throw new IllegalArgumentException("Invalid String Date Input");
		}
		//try/catch for parsing string date to Date type to compare past date attempts
		try {
			Date apptDate = sdf.parse(apptStrDate);
			
			if(apptDate.before(sdf.parse(sdf.format(new Date())))) {
				throw new IllegalArgumentException("Invalid Date Input");
			}
			this.apptDate = apptStrDate;
		}
		catch (ParseException e){
			throw new IllegalArgumentException("Invalid Date String Input");
		}
			
		
		if(desc == null || desc.isEmpty() || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Description Input");
		}
		this.apptID = apptID;
		this.desc = desc;
		
	}
	
	//set mutators, excluding apptID since it shall not be updatable
	public void setApptDate(String apptStrDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		if(apptStrDate == null || apptStrDate.isEmpty()) {
			throw new IllegalArgumentException("Invalid String Date Input");
		}
		
		try {
			Date apptDate = sdf.parse(apptStrDate);
			
			if(apptDate.before(sdf.parse(sdf.format(new Date())))) {
				throw new IllegalArgumentException("Invalid Date Input");
			}
			this.apptDate = apptStrDate;
		}
		catch (ParseException e){
			throw new IllegalArgumentException("Invalid Date String Input");
		}
	}
	
	public void setDesc(String desc) {
		if(desc == null || desc.isEmpty() || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Description Input");
		}
		this.desc = desc;
	}
	
	//get accessors
	public String getApptID() {
		return this.apptID;
	}
	public String getApptDate() {
		return this.apptDate;
	}
	public String getDesc() {
		return this.desc;
	}
}
