/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	//success case
	@Test
	void testAppointmentService() {
		AppointmentService appts = new AppointmentService();
		appts.addAppt("001", "2025-06-15", "Doctor Meng");
		appts.addAppt("002", "2025-12-30", "Dentist");
		appts.deleteAppt("001");
	}

	//test for duplicate ID
	@Test
	void testAppointmentServiceDuplicateID() {
		AppointmentService appts = new AppointmentService();
		appts.addAppt("001", "2025-06-15", "Doctor Meng");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appts.addAppt("001", "2025-12-30", "Dentist");
		});
	}
	
	//test for delete invalid ID
		@Test
		void testAppointmentServiceDeletePerIDNotFound() {
			AppointmentService appts = new AppointmentService();
			appts.addAppt("001", "2025-06-15", "Doctor Meng");
			
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appts.deleteAppt("002");
			});
		}
}
