/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

	//success case
	@Test
	void testTaskService() {
		TaskService tasks = new TaskService();
		tasks.addTask("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		tasks.addTask("002", "Bagging", "Placing items in bags for customers.");		
		tasks.updateName("001", "Cashiering");
		tasks.updateDesc("002", "Bagging groceries for customers.");
		tasks.deleteTask("001");
	}

	@Test
	void testTaskServiceAddDuplicate() {
		TaskService tasks = new TaskService();
		tasks.addTask("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tasks.addTask("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		});
	}
	
	@Test
	void testTaskServiceRemoveIDNotFound() {
		TaskService tasks = new TaskService();
		tasks.addTask("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tasks.deleteTask("002");
		});
	}
	
	@Test
	void testTaskServiceUpdateNamePerIDNotFound() {
		TaskService tasks = new TaskService();
		tasks.addTask("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tasks.updateName("002", "Bagging");
		});
	}
	
	@Test
	void testTaskServiceUpdateDescPerIDNotFound() {
		TaskService tasks = new TaskService();
		tasks.addTask("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			tasks.updateDesc("002", "Bagging groceries for customers.");
		});
	}
}
