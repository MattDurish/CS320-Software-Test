/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import java.util.ArrayList;

/*///////////////////////////////////////////
/ Class Purpose: 							/
/ To add tasks with a unique taskID			/
/ To delete tasks per taskID				/
/ To update task fields per taskID :		/
/   name, description						/
///////////////////////////////////////////*/

public class TaskService {
	//initialize a list of unique tasks for data usage
	public ArrayList<Task> tasks = new ArrayList<Task>();
	
	//find task method
	public int findTaskID(String taskID) {
		for(int i = 0; i < tasks.size(); i++) {
			if(tasks.get(i).getTaskID() == taskID) {
				//return index if found
				return i;
			}
		}
		//return -1 if not found
		return -1;
	}
		
	//add task method
	public void addTask(String taskID, String name, String desc) {
		int location = findTaskID(taskID);
			
		//add task if not found
		if(location == -1) {
			Task newTask = new Task(taskID, name, desc);
			tasks.add(newTask);
		} else {
			//taskID was found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	//delete task method
	public void deleteTask(String taskID) {
		int location = findTaskID(taskID);
			
		//if found, can remove from list
		if(location != -1) {
			tasks.remove(location);
		} else {
			//taskID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
	
	//update task methods
	public void updateName(String taskID, String name) {
		int location = findTaskID(taskID);
			
		//if found, can update name
		if(location != -1) {
			tasks.get(location).setName(name);
		} else {
			//taskID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
		
	public void updateDesc(String taskID, String desc) {
		int location = findTaskID(taskID);
			
		//if found, can update description
		if(location != -1) {
			tasks.get(location).setDesc(desc);
		} else {
			//taskID not found
			throw new IllegalArgumentException("Invalid Input");
		}
	}
		
}
