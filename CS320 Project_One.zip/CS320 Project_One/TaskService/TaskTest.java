/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	//success case
	@Test
	void testTask() {
		Task task = new Task("001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		assertTrue(task.getTaskID().equals("001"));
		assertTrue(task.getName().equals("Cleaning"));
		assertTrue(task.getDesc().equals("Trash, Bathrooms, Mats, Floors, Drink Station"));
		
		task.setName("Bagging");
		task.setDesc("Placing items in bags from customers.");
		assertTrue(task.getName().equals("Bagging"));
		assertTrue(task.getDesc().equals("Placing items in bags from customers."));
	}

	//taskID test for length and null
	@Test
	void testTaskIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("00000000001", "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		});
	}

	@Test
	void testTaskIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Cleaning", "Trash, Bathrooms, Mats, Floors, Drink Station");
		});
	}

	//name tests for length and null
	@Test
	void testNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("001", "c2l4e6a8n11i14n17g2000", "Trash, Bathrooms, Mats, Floors, Drink Station");
		});
	}
	
	@Test
	void testNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("001", null, "Trash, Bathrooms, Mats, Floors, Drink Station");
		});
	}
	
	//description tests for length and null
	@Test
	void testDescToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("001", "Cleaning", "T2r4a6s8h11,15 18B21a24t27h30r33o36o39m42s45,48 M52ats, Floors, Drink Station");
		});
	}
	
	@Test
	void testDescNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("001", "Cleaning", null);
		});
	}
}
