/*/////////////////////////////////////
/ Author	 : Matthew Durish         /
/ Date		 : 04/13/2025             /
/ Course	 : CS 320 Software Test   /
/ Instructor : Kuang-Jung Huang       /
/ Assignment : Project One			  /
/////////////////////////////////////*/

/*///////////////////////////////////////////////////////////////////////////
/ Class Purpose: 															/
/ To use in-memory data structures for a task list service including :	    /
/  Unique taskID no longer than 10 characters, never null, not updatable	/
/  String name no longer than 20 characters, never null						/
/  String description no longer than 50 characters, never null				/
///////////////////////////////////////////////////////////////////////////*/

public class Task {

	//unique string that cannot be longer than 10 characters, cannot be null, nor updatable
	private String taskID;
	//string that cannot be longer than 20 characters and cannot be null
	private String name;
	//string that cannot be longer than 50 characters and cannot be null
	private String desc;
	
	//Constructor
	public Task(String taskID, String name, String desc) {
		if(taskID == null || taskID.length() > 10) {
			//test for exception
			throw new IllegalArgumentException("Invalid Input");
		}
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid Input");
		}
		if(desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.taskID = taskID;
		this.name = name;
		this.desc = desc;
	}
	
	//set mutators, excluding taskID as per not updatable
	public void setName(String name) {
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.name = name;
	}
	public void setDesc(String desc) {
		if(desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Input");
		}
		this.desc = desc;
	}
	
	//get accessors
	public String getTaskID() {
		return this.taskID;
	}
	public String getName() {
		return this.name;
	}
	public String getDesc() {
		return this.desc;
	}
}
